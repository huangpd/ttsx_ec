from django.shortcuts import render, redirect
from models import User
from django.http import HttpResponse, JsonResponse, response
# Create your views here.
def register(request):
    return render(request,'account/register.html')
def register_handle(request):
    post = request.POST
    user_name = post.get('user_name')
    user_pwd = post.get('user_pwd')
    user_email = post.get('user_email')
    users = User()
    users.username = user_name
    users.password = user_pwd
    users.email = user_email
    users.save()
    return redirect('/login/')

def login(request):
    return render(request,'account/login.html')
def succes(request):
    return render(request,'account/succes.html')
def login_handle(request):
    post = request.POST
    user_name = post.get('username')
    user_pwd = post.get('userpwd')
    result = User.objects.filter(username=user_name,password=user_pwd)
    print(result)
    if result:
        return redirect('/succes/')
    else:
        return redirect('/login/')

